package com.amazon.DAL;

public class OrdersDAO {

}
